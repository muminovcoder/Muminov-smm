# Muminov Coder - Professional Portfolio

Bu mening shaxsiy portfolio veb-saytim. Unda mening ko'nikmalarim, xizmatlarim (Python, SMM, Telegram Bot) va bajarilgan loyihalarim aks etgan.

## 🚀 Xususiyatlar
- **Zamonaviy Dizayn:** Glassmorphism uslubi va animatsiyalar.
- **Moslashuvchanlik:** Barcha qurilmalar (telefon, planshet, kompyuter) uchun moslashgan.
- **Tezlik:** Optimizatsiya qilingan kod va tez yuklanish.
- **Xizmatlar:** Python Dasturlash, Telegram Botlar, SMM va Web Development.

## 🛠 Texnologiyalar
- HTML5
- CSS3 (Custom Variables, Animations)
- JavaScript (Vanilla JS)
- Font Awesome (Icons)
- Google Fonts (Outfit)

## 📦 O'rnatish va Ishga Tushirish

1. Repositoriyani kloning:
```bash
git clone https://github.com/kmuminov/muminov-coder-portfolio.git
